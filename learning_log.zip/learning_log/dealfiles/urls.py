"""为应用程序dealfiles定义URL模式"""

from django.conf.urls import url

from . import views

urlpatterns = [
	
	#文件上传界面
	url(r'^filesup/$', views.upload_file, name='filesup'),

]
