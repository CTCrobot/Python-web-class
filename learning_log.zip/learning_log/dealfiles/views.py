"""为dealfiles的视图"""

from django.http import  HttpResponseRedirect,HttpResponse
from django.urls import reverse
from django.shortcuts import render
from .forms import UploadFileForm

import re
import os

# Create your views here.

def handle_uploaded_file(file,user):
	
	path = 'dealfiles/file'
	filenum = int(len([lists for lists in os.listdir(path) if os.path.isfile(os.path.join(path, lists))]))
	print(filenum)
	pattern = re.compile(r'(.*)\.')
	file.name = pattern.sub(str(user)+'.',str(file.name))

	with open("dealfiles/file/%s" % file.name,'wb+') as f:
		for chunk in file.chunks():
			f.write(chunk)
	return filenum+1

def upload_file(request):
	if request.method != 'POST':
		form = UploadFileForm()
	else:
		form = UploadFileForm(request.POST,request.FILES)
		if form.is_valid():
			upnumber = handle_uploaded_file(request.FILES['file'],request.user)
			context = {'number': upnumber}
			return render(request,'dealfiles/upover.html',context)
	
	context = {'form': form}
	return render(request,'dealfiles/f2.html', context)	
