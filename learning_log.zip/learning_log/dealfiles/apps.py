from django.apps import AppConfig


class DealfilesConfig(AppConfig):
    name = 'dealfiles'
