from django import forms

	
class UploadFileForm(forms.Form):
#定义一个上传类
    title = forms.CharField(max_length=50)
#字段是字符串类型
    file = forms.FileField()
#字段是文件类型
