"""为dealfiles的视图"""

from django.http import  HttpResponseRedirect,HttpResponse
from django.urls import reverse
from django.shortcuts import render
from .forms import UploadFileForm
from django.contrib.auth.models import User
from django.contrib import messages

import re
import os,zipfile

# Create your views here.

def handle_uploaded_file(file,user):
	
	path = 'dealfiles/file'
	filenum = int(len([lists for lists in os.listdir(path) if os.path.isfile(os.path.join(path, lists))]))
	print(filenum)
	pattern = re.compile(r'(.*)\.')
	file.name = pattern.sub(str(user)+'.',str(file.name))

	with open("dealfiles/file/%s" % file.name,'wb+') as f:
		for chunk in file.chunks():
			f.write(chunk)
	return filenum+1

def upload_file(request):
	if request.method != 'POST':
		form = UploadFileForm()
	else:
		form = UploadFileForm(request.POST,request.FILES)
		if form.is_valid():
			upnumber = handle_uploaded_file(request.FILES['file'],request.user)
			context = {'number': upnumber}
			return render(request,'dealfiles/upover.html',context)
	
	context = {'form': form}
	return render(request,'dealfiles/upfile.html', context)	
	
def make_zip(source_dir, output_filename):
	zipf = zipfile.ZipFile(output_filename, 'w')
	pre_len = len(os.path.dirname(source_dir))
	for parent, dirnames, filenames in os.walk(source_dir):
		for filename in filenames:
			pathfile = os.path.join(parent, filename)
			arcname = pathfile[pre_len:].strip(os.path.sep)   #相对路径
			zipf.write(pathfile, arcname)
	zipf.close()

def download_file(request):
	user = User.objects.filter(is_superuser = True)
	user = re.findall(r":(.+?)>",str(user))
	print(str(user))
	print(request.user)
	if request.user != user:
		messages.warning(request,'No right!')
	else:
		make_zip("dealfiles/file", '机器人一班文件')
		filename = request_GET.get(u'dealfiles/file/机器人一班文件.zip')
		name = filename.split('/')[1]
		file = open(filename,mode='rb')
		response=FileResponse(file)
		response['Content-Type'] = 'application/octet-stream'
		response['Content-Disposition'] = 'attachment;filename="%s'%name		
		return response
	
	messages.success(request,'No right!')	
	return render(request,'dealfiles/upfile.html')
		
